<?php
  header ('Location: list_categories.php');
?>
