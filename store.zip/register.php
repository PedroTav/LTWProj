<?php
  include_once('config/init.php');
  
  include ('templates/header.php');
  include ('templates/register.php');
  include ('templates/footer.php');
?>
