<section id="content">
  <h2>Add Category</h2>
  <form action="action_add_category.php" method="post">
    <label>Name:
      <input type="text" name="name">
    </label>
    <input type="submit">
  </form>
</section>
