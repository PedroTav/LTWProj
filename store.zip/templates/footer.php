    <footer>
      &copy; 2015 &middot; Web Technologies
    </footer>
  </body>
</html>
