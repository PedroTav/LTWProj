<form action="action_logout.php">
  <?=$_SESSION['username']?> <input type="submit" value="Logout">
</form>
