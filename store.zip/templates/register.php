<section id="content">
  <h2>Register</h2>
  <form action="action_register.php" method="post">
    <label>Username:
      <input type="text" name="username">
    </label>
    <label>Password:
      <input type="password" name="password">
    </label>
    <input type="submit">
  </form>
</section>
